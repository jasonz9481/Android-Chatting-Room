#This is an instruction about how to boot up this Android Chatting Room app

About the server:

1.It's a Netbeans project, so please use Netbeans to open it if you want,or you can directly open the java file in the src directory.
2.If the port number is occupied,you can change it at line 41 in the 'Server.java' file.Please change it simultaneously in the client project,which is at the line 90 in the 'MainFrame' file.


About the client:

1.It's an AndroidStudio Project,and please use AndroidStudio to open it.
2.Before running this client project, you should run the server project first.
3.If connection fails, it may be the problem of the ip address.You can open the 'PublicChatAsyncTask.java' file and edit the line 97,which contains the ip address setting.Just change it to your local ip address.
4.You should run many times of this project to get many clients to check if the chatting works.

