package com.example.xiangjun.wifichatroom;

import android.app.AlertDialog;
import android.app.Application;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;


public class MainFrame extends ActionBarActivity {


    static EditText inputText;
    static boolean isFirst;
    static String userName;
    private ArrayAdapter<String> friendsListAdapter;
    static PublicChatAsyncTask publicChatAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_frame);

        TabHost tabHost = (TabHost) findViewById(R.id.tabHost);

        tabHost.setup();
        tabHost.addTab(tabHost.newTabSpec("privateChat").setIndicator("privateChat").setContent(R.id.tab1));
        tabHost.addTab(tabHost.newTabSpec("publicChat").setIndicator("groupChat").setContent(R.id.tab2));

        Intent intent = getIntent();
        userName = intent.getStringExtra("username");

        TextView showTextPrivate = (TextView) findViewById(R.id.showTextPrivate);
        showTextPrivate.setText("Hello，" + userName + "！The online users are listed below,please choose one of them!");


        isFirst = true;

        inputText = (EditText) findViewById(R.id.inputText);
        inputText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFirst == true) {
                    inputText.setText(null);
                    isFirst = false;
                }

            }
        });

        inputText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (isFirst == true) {
                    inputText.setText(null);
                    isFirst = false;
                }
                return false;
            }
        });

        ListView friendsList = (ListView) findViewById(R.id.friendsList);
        friendsListAdapter = new ArrayAdapter<String>(this, R.layout.friends_list_item);
        friendsList.setAdapter(friendsListAdapter);



        Button publicSendBtn = (Button) findViewById(R.id.sendBtn);
        TextView publicReceiveView = (TextView) findViewById(R.id.receiveView);


        boolean isConnected=intent.getBooleanExtra("isConnected",false);

        publicChatAsyncTask = new PublicChatAsyncTask(getApplicationContext(), userName,
                friendsListAdapter, publicSendBtn, inputText, publicReceiveView, this, friendsList,isConnected);
        publicChatAsyncTask.execute(6666);

    }

    //监听返回键
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            try {
                publicChatAsyncTask.returnKeyDown();
            } catch (Exception e) {
                publicChatAsyncTask.printException(e);
            }


        }

        return false;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
