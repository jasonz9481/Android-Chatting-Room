package com.example.xiangjun.wifichatroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;

public class PublicChatAsyncTask extends AsyncTask<Integer, String, Void> {

    static boolean isConnected;
    static private Socket socket;
    private PrintWriter writer;
    static private BufferedReader reader;
    static private MessageThread messageThread;
    private Map<String, User> onLineUsers = new HashMap<String, User>();
    private ArrayAdapter<String> friendsListAdapter;
    private String userName;
    private Context context;
    private Button publicSendBtn;
    private EditText publicInputText;
    private TextView publicReceiveView;
    private MainFrame thisFrame;
    private ListView friendsList;
    static AlertDialog.Builder dialogBuilder;
    static AlertDialog connectingDialog;
    static AlertDialog connectSuccessDialog;
    static AlertDialog connectFailureDialog;

    static String source = "";
    static String message = "";


    static boolean isFirstReceive = true;

    public PublicChatAsyncTask(Context context, String userName, ArrayAdapter<String> friendsListAdapter, Button publicSendBtn,
                               EditText publicInputText, TextView publicReceiveView, MainFrame thisFrame, ListView friendsList,
                               boolean isConnected) {
        this.context = context;
        this.userName = userName;
        this.friendsListAdapter = friendsListAdapter;
        this.publicSendBtn = publicSendBtn;
        this.publicInputText = publicInputText;
        this.publicReceiveView = publicReceiveView;
        this.thisFrame = thisFrame;
        this.friendsList = friendsList;
        this.isConnected = isConnected;
        dialogBuilder = new AlertDialog.Builder(thisFrame);
        connectingDialog = null;
        connectSuccessDialog = null;
        connectFailureDialog = null;
    }

    public static Socket getSocket() {
        return socket;
    }

    public static boolean isConnected() {
        return isConnected;
    }


    @Override
    protected Void doInBackground(Integer... params) {

        try {
            if (isConnected == false) {
                publishProgress("connecting");
                socket = new Socket("10.0.2.2", params[0]);
            }
            writer = new PrintWriter(socket.getOutputStream());
            reader = new BufferedReader(new InputStreamReader(socket
                    .getInputStream()));
            if(isConnected==false){
                sendMessage(userName + "@" + socket.getLocalAddress().toString());
            }
            else{
                sendMessage(userName+"@USERLIST");
            }

            messageThread = new MessageThread(reader);
            messageThread.start();
            isConnected = true;// connected


        } catch (IOException e) {
            publishProgress("connectFailure");
            isConnected = false;// not connected
        }

        publicSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected) {
                    publishProgress("We haven't connected to the server,and are not able to send message!");
                    return;
                }

                String publicInputTextString = publicInputText.getText().toString();
                if (publicInputTextString.isEmpty()) {
                    publishProgress("please input the messages!");
                    return;
                }
                sendMessage(userName + "@" + "ALL" + "@" + publicInputTextString);
                publicInputText.setText(null);
            }
        });

        friendsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String toName = (String) parent.getItemAtPosition(position);
                Intent privateChatIntent = new Intent();
                privateChatIntent.putExtra("toName", toName);
                privateChatIntent.putExtra("me", userName);
                privateChatIntent.putExtra("isChatted", false);
                privateChatIntent.setClass(context, PrivateChatFrame.class);
                thisFrame.startActivity(privateChatIntent);
            }
        });


        return null;

    }


    /**
     * Send messages
     *
     * @param message
     */
    public void sendMessage(String message) {
        writer.println(message);
        writer.flush();
    }

    public synchronized boolean closeConnection() {
        try {
            sendMessage("CLOSE");
            messageThread.stop();
            if (reader != null) {
                reader.close();
            }
            if (writer != null) {
                writer.close();
            }
            if (socket != null) {
                socket.close();
            }
            isConnected = false;
            return true;
        } catch (IOException e1) {
            e1.printStackTrace();
            isConnected = true;
            return false;

        }
    }

    // The thread to receive message
    class MessageThread extends Thread {
        private BufferedReader reader;

        public MessageThread(BufferedReader reader) {
            this.reader = reader;


        }

        public synchronized void closeCon() throws Exception {

            if (reader != null) {
                reader.close();
            }
            if (writer != null) {
                writer.close();
            }
            if (socket != null) {
                socket.close();
            }
            isConnected = false;
        }

        public void run() {
            String message = "";
            while (true) {
                try {
                    message = reader.readLine();
                    StringTokenizer stringTokenizer = new StringTokenizer(
                            message, "/@");
                    String command = stringTokenizer.nextToken();
                    if (command.equals("CLOSE"))
                    {

                        publishProgress("The server is closed!");
                        closeCon();
                        return;
                    } else if (command.equals("MAX")) {
                        closeCon();
                        publishProgress("The amount of chatting people has achieved the max!");
                        return;
                    } else if (command.equals("CONNECTSUCCESS")) {
                        String name_c = stringTokenizer.nextToken();
                        publishProgress("connectSuccess");
                    } else if (command.equals("USERLIST")) {
                        int size = Integer
                                .parseInt(stringTokenizer.nextToken());
                        String username = null;
                        String userIp = null;
                        for (int i = 0; i < size; i++) {
                            username = stringTokenizer.nextToken();
                            userIp = stringTokenizer.nextToken();
                            User user = new User(username, userIp);
                            onLineUsers.put(username, user);
                            publishProgress(null, null, username);
                        }
                    } else if (command.equals("ADD")) {
                        String username = "";
                        String userIp = "";
                        if ((username = stringTokenizer.nextToken()) != null
                                && (userIp = stringTokenizer.nextToken()) != null) {
                            User user = new User(username, userIp);
                            onLineUsers.put(username, user);
                            publishProgress(null, null, username);
                            publishProgress(username + "is online!");

                        }
                    } else if (command.equals("DELETE")) {
                        String username = stringTokenizer.nextToken();
                        User user = (User) onLineUsers.get(username);
                        onLineUsers.remove(user);
                        publishProgress(null, null, null, username);
                        publishProgress(username + "is offline!");
                    } else if (command.equals("PRIVATEINFO")) {
                        String source = stringTokenizer.nextToken();
                        String privateMessage = stringTokenizer.nextToken();
                        publishProgress(null, null, null, null, source + "@" + privateMessage);
                        return;
                    } else if (command.equals("CLOSEPUBLICTHREAD")) {
                        return;
                    } else {
                        publishProgress(null, message);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
    }

    public void returnKeyDown() {
        publishProgress("returnKey");
    }

    public void printException(Exception e) {
        e.printStackTrace();
    }

    public void restartMessageThread() {
        messageThread.start();
    }

    protected void onProgressUpdate(String... progress) {
        if (progress[0] != null) {
            if (progress[0].equals("connecting")) {
                dialogBuilder.setMessage("Connecting......");
                dialogBuilder.setTitle("");
                dialogBuilder.setCancelable(false);
                connectingDialog = dialogBuilder.create();
                connectingDialog.show();
            } else if (progress[0].equals("connectSuccess")) {
                new Handler().postDelayed(new Runnable() {

                    public void run() {

                        connectingDialog.dismiss();
                        dialogBuilder.setMessage("Connected!");
                        dialogBuilder.setCancelable(true);
                        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        connectSuccessDialog = dialogBuilder.create();
                        connectSuccessDialog.show();

                    }

                }, 2000);
            } else if (progress[0].equals("connectFailure")) {
                new Handler().postDelayed(new Runnable() {

                    public void run() {

                        connectingDialog.dismiss();
                        dialogBuilder.setMessage("Connecting fails");
                        dialogBuilder.setCancelable(true);
                        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                Intent intent = new Intent();
                                intent.setClass(thisFrame, LoginFrame.class);
                                thisFrame.startActivity(intent);
                            }
                        });
                        connectFailureDialog = dialogBuilder.create();
                        connectFailureDialog.setCanceledOnTouchOutside(false);
                        connectFailureDialog.show();
                    }

                }, 2000);
            } else if (progress[0].equals("returnKey")) {
                AlertDialog.Builder returnKeybuilder = new AlertDialog.Builder(thisFrame);
                returnKeybuilder.setMessage("Are you sure to exit?");
                returnKeybuilder.setTitle("");
                returnKeybuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        boolean flag = closeConnection();
                        if (flag == false) {
                            Toast.makeText(context, "The connections throws a exception！", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Intent intent = new Intent();
                        intent.setClass(thisFrame, LoginFrame.class);
                        thisFrame.startActivity(intent);
                    }
                });
                returnKeybuilder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                returnKeybuilder.show();

            } else
                Toast.makeText(context, progress[0], Toast.LENGTH_SHORT).show();
        } else if (progress[1] != null)
        {
            if (isFirstReceive == true) {
                publicReceiveView.setText(progress[1] + "\n");
                isFirstReceive = false;
            } else
                publicReceiveView.append(progress[1] + "\n");
        } else if (progress[2] != null)
            friendsListAdapter.add(progress[2]);
        else if (progress[3] != null)
            friendsListAdapter.remove(progress[3]);
        else if (progress[4] != null)
        {

            StringTokenizer stringTokenizer = new StringTokenizer(progress[4], "@");
            source = stringTokenizer.nextToken();
            message = stringTokenizer.nextToken();

            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(thisFrame);
            alertBuilder.setMessage("You got a message from " + source + ",do you want to check it？");
            alertBuilder.setTitle("Alert");

            alertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent privateChatIntent = new Intent();
                    privateChatIntent.putExtra("toName", source);
                    privateChatIntent.putExtra("me", userName);
                    privateChatIntent.putExtra("isChatted", true);
                    privateChatIntent.putExtra("message", source + "：" + message);
                    privateChatIntent.setClass(context, PrivateChatFrame.class);
                    thisFrame.startActivity(privateChatIntent);

                }
            });

            alertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            alertBuilder.show();
        }
    }

}

