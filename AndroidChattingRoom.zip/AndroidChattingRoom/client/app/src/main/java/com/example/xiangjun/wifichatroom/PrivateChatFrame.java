package com.example.xiangjun.wifichatroom;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;


public class PrivateChatFrame extends ActionBarActivity {

    static EditText privateInputText;
    static boolean isFirstClick=true,isFirstInput=true;
    static private Socket socket;
    static private PrintWriter writer;
    static private BufferedReader reader;
    static PrivateChatAsyncTask privateChatAsyncTask;
    private boolean isFirstReceive=true;
    static String me,toName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_chat_frame);

        Intent intent=getIntent();
        toName=intent.getStringExtra("toName");
        this.setTitle("chatting with" + toName);
        me=intent.getStringExtra("me");

        Button privateSendBtn=(Button)findViewById(R.id.sendBtn);


        privateInputText=(EditText)findViewById(R.id.inputText);
        privateInputText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFirstClick == true) {
                    privateInputText.setText(null);
                    isFirstClick = false;
                }

            }
        });

        privateInputText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (isFirstInput == true) {
                    privateInputText.setText(null);
                    isFirstInput = false;
                }
                return false;
            }
        });

        TextView privateReceiveView=(TextView)findViewById(R.id.receiveView);

        boolean isChatted=intent.getBooleanExtra("isChatted",false);
        if(isChatted==true)
        {
            String message=intent.getStringExtra("message");
            privateReceiveView.setText(message+"\n");
            isFirstReceive=false;
        }

        privateChatAsyncTask=new PrivateChatAsyncTask(toName,me,getApplicationContext(),privateSendBtn,
                privateInputText,privateReceiveView,isFirstReceive,isChatted);
        privateChatAsyncTask.execute();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            privateChatAsyncTask.stopMessageThread();
            Intent intent=new Intent();
            intent.putExtra("username",me);
            intent.putExtra("isConnected",true);
            intent.setClass(PrivateChatFrame.this,MainFrame.class);
            startActivity(intent);
        }

        return false;
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_private_chat_frame, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
