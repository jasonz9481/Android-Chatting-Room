package com.example.xiangjun.wifichatroom;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class PrivateChatAsyncTask extends AsyncTask<Integer, String, Void> {


    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    static private MessageThread messageThread;

    private String toName;
    private String me;
    private Context context;
    private Button privateSendBtn;
    private EditText privateInputText;
    private TextView privateReceiveView;
    private boolean isFirstReceive;
    static private boolean isChatted;

    public PrivateChatAsyncTask(String toName, String me, Context context, Button privateSendBtn,
                                EditText privateInputText, TextView privateReceiveView, boolean isFirstReceive,
                                boolean isChatted) {
        this.toName = toName;
        this.me = me;
        this.context = context;
        this.privateSendBtn = privateSendBtn;
        this.privateInputText = privateInputText;
        this.privateReceiveView = privateReceiveView;
        this.isFirstReceive = isFirstReceive;
        this.isChatted = isChatted;
    }

    @Override
    protected Void doInBackground(Integer... params) {

        socket = PublicChatAsyncTask.getSocket();


        try {
            writer = new PrintWriter(socket.getOutputStream());
            reader = new BufferedReader(new InputStreamReader(socket
                    .getInputStream()));
            messageThread = new MessageThread(reader);
            messageThread.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

        privateSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String privateInputTextString = privateInputText.getText().toString();
                if (privateInputTextString.isEmpty()) {
                    publishProgress("Pleas input some messages");
                    return;
                }

                sendMessage(me + "@" + "PRIVATE" + "@" + privateInputTextString + "@" + toName);
                publishProgress(null, "Me：" + privateInputTextString);
                privateInputText.setText(null);
            }
        });


        return null;

    }


    /**
     * 发送消息
     *
     * @param message
     */
    public void sendMessage(String message) {
        writer.println(message);
        writer.flush();
    }

    public void stopMessageThread() {
        sendMessage(me+"@CLOSEPRIVATETHREAD");
    }


    class MessageThread extends Thread {
        private BufferedReader reader;


        public MessageThread(BufferedReader reader) {
            this.reader = reader;


        }

        public synchronized void closeCon() throws Exception {

            if (reader != null) {
                reader.close();
            }
            if (writer != null) {
                writer.close();
            }
            if (socket != null) {
                socket.close();
            }

        }

        public void run() {
            String message = "";
            while (true) {
                try {
                    message = reader.readLine();
                    StringTokenizer stringTokenizer = new StringTokenizer(
                            message, "@");
                    String command = stringTokenizer.nextToken();
                    //publishProgress(null,message);
                    if (command.equals("PRIVATEINFO")) {
                        String source = stringTokenizer.nextToken();
                        String privateMessage = stringTokenizer.nextToken();
                        publishProgress(null, source + "：" + privateMessage + "\n");
                    }else if(command.equals("CLOSEPRIVATETHREAD")){
                        return;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
    }


    protected void onProgressUpdate(String... progress) {
        if (progress[0] != null)
            Toast.makeText(context, progress[0], Toast.LENGTH_SHORT).show();
        else if (progress[1] != null)
        {
            if (isFirstReceive == true) {
                privateReceiveView.setText(progress[1] + "\n");
                isFirstReceive = false;
            } else
                privateReceiveView.append(progress[1] + "\n");
        }

    }

}

