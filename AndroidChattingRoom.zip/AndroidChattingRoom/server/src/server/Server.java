/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author xiangjun
 */
public class Server {

    /**
     * @param args the command line arguments
     */
    static private ServerSocket serverSocket;
    private ServerThread serverThread;
    static private ArrayList<ClientThread> clients;
    static private boolean isStart = false;

    public static void main(String[] args) throws BindException {
        // TODO code application logic here
        new Server();

    }

    public Server() throws BindException {

        serverStart(30, 6666);
    }

    public void serverStart(int max, int port) throws java.net.BindException {
        try {
            clients = new ArrayList<ClientThread>();
            serverSocket = new ServerSocket(port);
            serverThread = new ServerThread(serverSocket, max);
            serverThread.start();
            System.out.println("The server boots up successfully!\n");
            isStart = true;
        } catch (BindException e) {
            isStart = false;
            throw new BindException("The port number has been occupied,please change another one!");
        } catch (Exception e1) {
            e1.printStackTrace();
            isStart = false;
            throw new BindException("It throws an exception while booting up!");
        }
    }

    @SuppressWarnings("deprecation")
    public void closeServer() {
        try {
            if (serverThread != null) {
                serverThread.stop();
            }
            for (int i = clients.size() - 1; i >= 0; i--) {
                clients.get(i).getWriter().println("CLOSE");
                clients.get(i).getWriter().flush();
                clients.get(i).stop();
                clients.get(i).reader.close();
                clients.get(i).writer.close();
                clients.get(i).socket.close();
                clients.remove(i);
            }
            if (serverSocket != null) {
                serverSocket.close();
            }
            isStart = false;
        } catch (IOException e) {
            e.printStackTrace();
            isStart = true;
        }
    }

    class ServerThread extends Thread {

        private ServerSocket serverSocket;
        private int max;


        public ServerThread(ServerSocket serverSocket, int max) {
            this.serverSocket = serverSocket;
            this.max = max;
        }

        public void run() {
            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    boolean flag = false;

                    BufferedReader r = new BufferedReader(
                            new InputStreamReader(socket.getInputStream()));
                    PrintWriter w = new PrintWriter(socket
                            .getOutputStream());

                    String inf = r.readLine();
                    StringTokenizer st = new StringTokenizer(inf, "@");
                    User user = new User(st.nextToken(), st.nextToken());
                    if (clients.size() == max) {  
                        w.println("MAX@Server: Sorry" + user.getName()
                                + user.getIp() + "，the connecting number of clients has acheived the max,pleas reconnect after a while!");
                        w.flush();
                        //release the sourses
                        r.close();
                        w.close();
                        socket.close();
                        continue;
                    } else {
                        for (int i = clients.size() - 1; i >= 0; i--) {
                            if (clients.get(i).getUser().getName().equals(user.getName())) {
                                w.println("ISCONNECTED@Sorry,this username has been occupied!Please change another one");
                                w.flush();
                                r.close();
                                w.close();
                                socket.close();
                                flag = true;
                                break;
                            }
                        }

                        if (flag == true) {
                            continue;
                        }
                    }
                    w.println("CONNECTSUCCESS@" + user.getName());
                    w.flush();

                    System.out.println(user.getName() + "is online!\n");

                    ClientThread client = new ClientThread(socket, r, w, user);

                    client.start();

                    clients.add(client);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // It's a thread of serving every client
    class ClientThread extends Thread {

        private Socket socket;
        private BufferedReader reader;
        private PrintWriter writer;
        private User user;

        public BufferedReader getReader() {
            return reader;
        }

        public PrintWriter getWriter() {
            return writer;
        }

        public User getUser() {
            return user;
        }

        public ClientThread(Socket socket, BufferedReader reader, PrintWriter writer, User user) {

            this.socket = socket;
            this.reader = reader;
            this.writer = writer;
            this.user = user;
            // feedback the online people to client
            if (clients.size() > 0) {
                String temp = "";
                for (int i = clients.size() - 1; i >= 0; i--) {
                    temp += (clients.get(i).getUser().getName() + "/" + clients
                            .get(i).getUser().getIp())
                            + "@";
                }
                writer.println("USERLIST@" + clients.size() + "@" + temp);
                writer.flush();
            }

            for (int i = clients.size() - 1; i >= 0; i--) {
                clients.get(i).getWriter().println(
                        "ADD@" + user.getName() + user.getIp());
                clients.get(i).getWriter().flush();
            }

        }

        @SuppressWarnings("deprecation")
        public void run() {//handle the messages from the client
            String message = null;
            while (true) {
                try {
                    message = reader.readLine();
                    if (message.equals("CLOSE"))//offline
                    {

                        reader.close();
                        writer.close();
                        socket.close();

                        // send the offline information to all the clients
                        for (int i = clients.size() - 1; i >= 0; i--) {
                            clients.get(i).getWriter().println(
                                    "DELETE@" + user.getName());
                            clients.get(i).getWriter().flush();
                        }
                        System.out.println(user.getName() + "is offline!\n");

                        for (int i = clients.size() - 1; i >= 0; i--) {
                            if (clients.get(i).getUser() == user) {
                                ClientThread temp = clients.get(i);
                                clients.remove(i);// delete this client's thread
                                temp.stop();
                                return;
                            }
                        }

                    }  else {
                        dispatcherMessage(message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public void dispatcherMessage(String message) throws IOException {
            StringTokenizer stringTokenizer = new StringTokenizer(message, "@");
            System.out.println("\n" + message + "\n");
            String source = stringTokenizer.nextToken();
            String order = stringTokenizer.nextToken();

            if (order.equals("ALL")) {// groupChat
                String content = stringTokenizer.nextToken();
                for (int i = clients.size() - 1; i >= 0; i--) {
                    if (clients.get(i).getUser().getName().equals(source)) {
                        message = "Me to all：" + content;
                    } else {
                        message = source + " to all：" + content;
                    }
                    clients.get(i).getWriter().println(message);
                    clients.get(i).getWriter().flush();
                }
            } else if (order.equals("PRIVATE")) {//private chat
                String content = stringTokenizer.nextToken();
                String chatWith = stringTokenizer.nextToken();
                message = content;
                for (int i = clients.size() - 1; i >= 0; i--) {
                    if (clients.get(i).getUser().getName().equals(chatWith)) {
                        clients.get(i).getWriter().println("PRIVATEINFO@" + source + "@" + message);
                        clients.get(i).getWriter().flush();
                        for (int j = clients.size() - 1; j >= 0; j--) {
                            if (clients.get(j).getUser().getName().equals(source)) {
                                clients.get(j).getWriter().println("CLOSEPUBLICTHREAD@hehe");
                                clients.get(j).getWriter().flush();
                            }
                        }
                        return;
                    }

                }
            } else if (order.equals("CLOSEPRIVATETHREAD")) {

                for (int j = clients.size() - 1; j >= 0; j--) {
                    if (clients.get(j).getUser().getName().equals(source)) {
                        clients.get(j).getWriter().println("CLOSEPRIVATETHREAD");
                        clients.get(j).getWriter().flush();
                    }
                }
                return;

            } else if (order.equals("USERLIST")) {
                if (clients.size() > 0) {
                    String temp = "";
                    for (int i = clients.size() - 1; i >= 0; i--) {
                        if(!clients.get(i).getUser().getName().equals(source))
                            temp += (clients.get(i).getUser().getName() + "/" + clients
                                .get(i).getUser().getIp())
                                + "@";
                    }
                    writer.println("USERLIST@" + (clients.size()-1) + "@" + temp);
                    writer.flush();
                }

            } 

        }

    }

}
